/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 *
 * Genius integration: Genius supplies the lyric text; LrcLib/YouLyPlus
 * supplies timestamps. The two are matched line-by-line before returning LRC.
 */

package moe.rukamori.archivetune.lyrics

import android.content.Context
import android.text.Html
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * Genius is used only as a text source. It is deliberately paired with a
 * timestamp source so ArchiveTune still receives normal synced LRC.
 *
 * Search is performed through geniURL (a small public Genius search proxy),
 * while the selected Genius song page is fetched directly for the lyric text.
 */
object GeniusSyncedLyricsProvider : LyricsProvider {
    override val name: String = "Genius (synced)"

    private val client by lazy {
        OkHttpClient.Builder()
            .callTimeout(10, TimeUnit.SECONDS)
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    override fun isEnabled(context: Context): Boolean = true

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        album: String?,
        duration: Int,
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val geniusLyrics = fetchGeniusLyrics(title, artist)
                ?: throw IllegalStateException("Genius lyrics not found")

            val syncedCandidates = coroutineScope {
                listOf(
                    async {
                        runCatching {
                            LrcLibLyricsProvider.getLyrics(id, title, artist, album, duration).getOrNull()
                        }.getOrNull()
                    },
                    async {
                        runCatching {
                            YouLyPlusLyricsProvider.getLyrics(id, title, artist, album, duration).getOrNull()
                        }.getOrNull()
                    },
                ).awaitAll().filterNotNull()
            }

            val synced = syncedCandidates
                .filter { LyricsUtils.isLineSyncedLrc(it) }
                .maxByOrNull { scoreSynced(it) }
                ?: throw IllegalStateException("No line-synced lyrics available for timestamp matching")

            val merged = mergeLyrics(geniusLyrics, synced)
                ?: throw IllegalStateException("Genius lyrics could not be matched to synced lyrics")

            merged
        }
    }

    private fun fetchGeniusLyrics(title: String, artist: String): String? {
        val searchUrl =
            "https://api.sv443.net/geniurl/search/top?artist=${enc(artist)}&song=${enc(title)}&format=json&threshold=0.65"
        val searchBody = fetch(searchUrl) ?: return null
        val search = runCatching { JSONObject(searchBody) }.getOrNull() ?: return null
        if (search.optBoolean("error", true)) return null

        val top = search.optJSONObject("top") ?: return null
        val geniusTitle = top.optJSONObject("meta")?.optString("title").orEmpty()
        val meta = top.optJSONObject("meta")
        val geniusArtist = meta?.optJSONObject("primaryArtist")?.optString("name")
            ?.takeIf { it.isNotBlank() }
            ?: meta?.optString("artists").orEmpty()
        val url = top.optString("url").ifBlank {
            val path = top.optString("path")
            if (path.isBlank()) "" else "https://genius.com$path"
        }
        if (url.isBlank()) return null

        if (!titleMatches(title, geniusTitle) || !artistMatches(artist, geniusArtist)) return null

        val html = fetch(url) ?: return null
        return extractLyrics(html)
    }

    private fun extractLyrics(html: String): String? {
        val chunks = mutableListOf<String>()

        // Current Genius pages use data-lyrics-container="true".
        val current = Regex(
            """<div[^>]*data-lyrics-container=["']true["'][^>]*>(.*?)</div>""",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE),
        )
        current.findAll(html).forEach { match ->
            chunks += htmlToText(match.groupValues[1])
        }

        // Older pages used a single .lyrics container.
        if (chunks.isEmpty()) {
            val legacy = Regex(
                """<div[^>]*class=["'][^"']*lyrics[^"']*["'][^>]*>(.*?)</div>""",
                setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE),
            )
            legacy.findAll(html).forEach { match -> chunks += htmlToText(match.groupValues[1]) }
        }

        val result = chunks
            .map { it.replace("\r", "").trim() }
            .filter { it.lines().count(String::isNotBlank) >= 2 }
            .joinToString("\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()

        if (result.isBlank()) return null
        if (result.lines().count(String::isNotBlank) < 3) return null
        if (result.matches(Regex("""(?i)^\d+ contributors$"""))) return null
        return result
    }

    private fun htmlToText(fragment: String): String {
        val withBreaks = fragment
            .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("</p>\\s*<p>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), "")
        return Html.fromHtml(withBreaks, Html.FROM_HTML_MODE_LEGACY).toString()
    }

    private fun mergeLyrics(genius: String, synced: String): String? {
        val geniusLines = cleanGeniusLines(genius)
        val syncLines = parseLrc(synced)
        if (geniusLines.size < 3 || syncLines.size < 3) return null

        val matches = mutableListOf<Int?>()
        var cursor = 0
        var matched = 0

        for (line in geniusLines) {
            var bestIndex = -1
            var bestScore = 0.0
            val end = min(syncLines.size, cursor + 8)
            for (i in cursor until end) {
                val score = lineSimilarity(line, syncLines[i].text)
                if (score > bestScore) {
                    bestScore = score
                    bestIndex = i
                }
            }
            if (bestIndex >= 0 && bestScore >= 0.46) {
                matches += bestIndex
                cursor = bestIndex + 1
                matched++
            } else {
                matches += null
            }
        }

        val coverage = matched.toDouble() / geniusLines.size
        if (coverage < 0.72 || matched < 5) return null

        val output = StringBuilder()
        var lastTime = 0L
        for (i in geniusLines.indices) {
            val time = matches[i]?.let { syncLines[it].timeMs }
                ?: inferTime(matches, i, syncLines)
            if (time < lastTime) continue
            output.append(formatLrcTime(time)).append(geniusLines[i]).append('\n')
            lastTime = time
        }

        return output.toString().trim().takeIf { LyricsUtils.isLineSyncedLrc(it) }
    }

    private fun cleanGeniusLines(text: String): List<String> = text.lines()
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .filterNot { it.matches(Regex("""^\d+ contributors$""", RegexOption.IGNORE_CASE)) }
        .filterNot { it.matches(Regex("""^\d+.*contributors.*$""", RegexOption.IGNORE_CASE)) }

    private data class SyncLine(val timeMs: Long, val text: String)

    private fun parseLrc(lrc: String): List<SyncLine> {
        val regex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\](.*)""")
        return lrc.lines().flatMap { line ->
            regex.findAll(line).mapNotNull { m ->
                val minutes = m.groupValues[1].toLongOrNull() ?: return@mapNotNull null
                val seconds = m.groupValues[2].toLongOrNull() ?: return@mapNotNull null
                val fraction = m.groupValues[3]
                val millis = when (fraction.length) {
                    0 -> 0L
                    1 -> fraction.toLong() * 100L
                    2 -> fraction.toLong() * 10L
                    else -> fraction.take(3).toLong()
                }
                SyncLine((minutes * 60_000L) + (seconds * 1_000L) + millis, m.groupValues[4].trim())
                    .takeIf { it.text.isNotBlank() }
            }
        }.toList().sortedBy { it.timeMs }
    }

    private fun lineSimilarity(a: String, b: String): Double {
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        if (x == y) return 1.0
        if (x.contains(y) || y.contains(x)) return 0.88
        val xt = x.split(' ').filter { it.isNotBlank() }.toSet()
        val yt = y.split(' ').filter { it.isNotBlank() }.toSet()
        val intersection = xt.intersect(yt).size.toDouble()
        val union = xt.union(yt).size.toDouble().coerceAtLeast(1.0)
        val jaccard = intersection / union
        val prefix = commonPrefix(x, y).toDouble() / max(x.length, y.length).coerceAtLeast(1)
        return (jaccard * 0.85) + (prefix * 0.15)
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace(Regex("\\[[^]]*]"), " ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun commonPrefix(a: String, b: String): Int {
        var i = 0
        val n = min(a.length, b.length)
        while (i < n && a[i] == b[i]) i++
        return i
    }

    private fun inferTime(matches: List<Int?>, index: Int, sync: List<SyncLine>): Long {
        for (i in index - 1 downTo 0) matches[i]?.let { return sync[it].timeMs + 1L }
        for (i in index + 1 until matches.size) matches[i]?.let { return max(0L, sync[it].timeMs - 1L) }
        return 0L
    }

    private fun formatLrcTime(ms: Long): String {
        val totalMinutes = ms / 60_000L
        val seconds = (ms % 60_000L) / 1_000L
        val hundredths = (ms % 1_000L) / 10L
        return "[%02d:%02d.%02d]".format(Locale.ROOT, totalMinutes, seconds, hundredths)
    }

    private fun scoreSynced(lrc: String): Int = lrc.lines().count { it.matches(Regex("""\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\].+""")) }

    private fun titleMatches(requested: String, found: String): Boolean {
        val a = normalize(requested)
        val b = normalize(found)
        return a == b || a.contains(b) || b.contains(a) || lineSimilarity(a, b) >= 0.55
    }

    private fun artistMatches(requested: String, found: String): Boolean {
        val req = normalize(requested).split(' ').filter { it.length > 1 }.toSet()
        val got = normalize(found).split(' ').filter { it.length > 1 }.toSet()
        if (req.isEmpty() || got.isEmpty()) return true
        return req.intersect(got).isNotEmpty()
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun fetch(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36")
            .header("Accept", "text/html,application/json;q=0.9,*/*;q=0.8")
            .build()
        return runCatching {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) null else response.body?.string()
            }
        }.getOrNull()
    }
}
